1. Open Number_Plate_Reader.m file
2.Run it